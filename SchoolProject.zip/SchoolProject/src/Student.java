public class Student {
    String firstNameStudent;
    String lastNameStudent;
    int grade;
    int studentNumber;
    int idNumber = 0;



    Student(){
        firstNameStudent = "";
        lastNameStudent = "";
        grade = 0;
        studentNumber = idNumber;
        idNumber++;
    }

    //Sets the values of the variables to the values inputed when a new Student object is made
    Student(String firstNameStudent, String lastNameStudent, int grade){
        this.firstNameStudent = firstNameStudent;
        this.lastNameStudent = lastNameStudent;
        this.grade = grade;
    }

    public String getFirstNameStudent() {
        return firstNameStudent;
    }

    public void setFirstNameStudent(String firstNameStudent) {
        this.firstNameStudent = firstNameStudent;
    }

    public String getLastNameStudent() {
        return lastNameStudent;
    }

    public void setLastNameStudent(String lastNameStudent) {
        this.lastNameStudent = lastNameStudent;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }

    //When the array list is printed, this is what the viewer will read, with the specific values inputed for each student shown.
    public String toString(){
        return "Name: " + this.firstNameStudent + " " + this.lastNameStudent + " Grade: " + this.grade;
    }
}
