public class Teacher {
    public static Object add;
    public String firstNameTeacher;
    public String lastNameTeacher;
    public String subjectTeacher;

    Teacher(){
        firstNameTeacher = "";
        lastNameTeacher = "";
        subjectTeacher = "";

    }

    //Sets the values of the variables to the values inputed when a new Teacher object is made
    Teacher(String firstNameTeacher, String lastNameTeacher, String subjectTeacher){
        this.firstNameTeacher = firstNameTeacher;
        this.lastNameTeacher = lastNameTeacher;
        this.subjectTeacher = subjectTeacher;
    }



    public String getFirstNameTeacher() {
        return firstNameTeacher;
    }

    public void setFirstNameTeacher(String firstNameTeacher) {
        this.firstNameTeacher = firstNameTeacher;
    }

    public String getLastNameTeacher() {
        return lastNameTeacher;
    }

    public void setLastNameTeacher(String lastNameTeacher) {
        this.lastNameTeacher = lastNameTeacher;
    }

    public String getSubjectTeacher() {
        return subjectTeacher;
    }

    public void setSubjectTeacher(String subjectTeacher) {
        this.subjectTeacher = subjectTeacher;
    }

    //When the array list is printed, this is what the viewer will read, with the specific values inputed shown.
    public String toString(){
        return "Name: " + this.firstNameTeacher + " " + this.lastNameTeacher + " Subject: " + this.subjectTeacher;
    }

}
