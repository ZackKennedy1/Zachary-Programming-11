import java.util.ArrayList;

public class School {
    //Array lists hold the teachers and students created in the main class
    public static ArrayList<Teacher> teachers = new ArrayList<>();
    public static ArrayList<Student> students = new ArrayList<>();
    public ArrayList<String> courses = new ArrayList<String>();
    private String name;
    private String location;
    private int schoolRating  = 0;
    School(){
        name = "";
        location = "";
        schoolRating = 0;

    }
    //Sets the values of the variables to the values inputed when a new School object is made
    School(String name, String location, int schoolRating){
        this.name = name;
        this.location = location;
        this.schoolRating = schoolRating;
    }
    //Following two methods are used to add a teacher or student to their array lists
    public static void add(Teacher teacher){
        teachers.add(teacher);
    }
    public static void add(Student student){
        students.add(student);
    }

    //Following two methods are used to remove a student or teacher from their array list at a chosen index position
    public static void removeStudent(int i){
        students.remove(i);
    }
    public static void removeTeacher(int i){
        teachers.remove(i);
    }

    //Following two methods print out the array lists when called
    public static void displayTeachers(){
        System.out.println(teachers);
    }
    public static void displayStudents(){
        System.out.println(students);
    }

}
