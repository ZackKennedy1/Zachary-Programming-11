public class Main {
    public static void main(String[] args) {
  //Creating each of the ten students and adding them to the students arrayList
    Student createdStudent1 = new Student("John", "James", 3);
    School.add(createdStudent1);
        Student createdStudent2 = new Student("Jamie-Lee", "Bray", 7);
        School.add(createdStudent2);
        Student createdStudent3 = new Student("Grover", "Monroe", 1);
        School.add(createdStudent3);
        Student createdStudent4 = new Student("Daanish", "Enriquez", 4);
        School.add(createdStudent4);
        Student createdStudent5 = new Student("Georgia", "Russo", 6);
        School.add(createdStudent5);
        Student createdStudent6 = new Student("Holli", "Zhang", 7);
        School.add(createdStudent6);
        Student createdStudent7 = new Student("Billy-Joe", "Mccray", 2);
        School.add(createdStudent7);
        Student createdStudent8 = new Student("Melanie", "Herring", 2);
        School.add(createdStudent8);
        Student createdStudent9 = new Student("Omer", "Bellamy", 5);
        School.add(createdStudent9);
        Student createdStudent10 = new Student("Danyl", "Davey", 3);
        School.add(createdStudent10);

        //Creating each of the three teachers and adding them to the teachers arrayList
        Teacher createdTeacher = new Teacher("Thomas", "Adams", "Science");
    School.add(createdTeacher);
        Teacher createdTeacher2 = new Teacher("Teddy", "Samuels", "English");
        School.add(createdTeacher2);
        Teacher createdTeacher3 = new Teacher("Simra", "Ritter", "Math");
        School.add(createdTeacher3);

        //Calling the methods that displays the array lists
School.displayStudents();
School.displayTeachers();

//Removing students and teachers at a chosen index position in the array list
for(int k=0;k<2;k++) {
    School.removeStudent(0);
}
School.removeTeacher(0);

//Calling again the methods that displays the array lists
        School.displayStudents();
        School.displayTeachers();
    }
}
